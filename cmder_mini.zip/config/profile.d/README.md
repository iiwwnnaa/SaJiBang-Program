## Profile.d Folder

* Files in this folder named `*.{sh|cmd|ps1}`: Will be executed by the appropriate shell when starting the shell.
